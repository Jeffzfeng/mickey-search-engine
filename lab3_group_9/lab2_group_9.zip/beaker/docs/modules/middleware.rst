:mod:`beaker.middleware` -- Middleware classes 
==============================================

.. automodule:: beaker.middleware

Module Contents
---------------

.. autoclass:: CacheMiddleware
.. autoclass:: SessionMiddleware
