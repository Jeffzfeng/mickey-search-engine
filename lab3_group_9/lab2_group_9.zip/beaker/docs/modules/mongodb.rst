:mod:`beaker.ext.mongodb` -- MongoDB NameSpace Manager and Synchronizer
==============================================================================

.. automodule:: beaker.ext.mongodb

Module Contents
---------------

.. autoclass:: MongoNamespaceManager
.. autoclass:: MongoSynchronizer
