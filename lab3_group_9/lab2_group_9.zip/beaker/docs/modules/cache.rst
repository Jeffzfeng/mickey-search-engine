:mod:`beaker.cache` -- Cache module 
================================================

.. automodule:: beaker.cache

Module Contents
---------------

.. autodata:: beaker.cache.cache_regions
.. autofunction:: cache_region
.. autofunction:: region_invalidate
.. autoclass:: Cache
    :members: get, clear
.. autoclass:: CacheManager
    :members: region, region_invalidate, cache, invalidate
